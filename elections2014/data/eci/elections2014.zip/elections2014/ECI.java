import java.io.*;
import java.util.*;
import java.net.*;


public class ECI {

public void ecirun() {

	while(true) {
		try {
			String filename = (new Date()).toString();
			BufferedWriter bw = new BufferedWriter(new FileWriter(filename));
			String line = null;
		        URL url = new URL("http://eciresults.nic.in");
        		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        		BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		        while (rd.readLine() != null) {
           			line += rd.readLine();
        		}
        		bw.write(line);
			bw.close();
			Thread.sleep(6000);
		} catch (Exception ex)  {
			ex.printStackTrace();
		}
			
	}

}
	
public static void main(String args[]) {
	ECI eci = new ECI();
	eci.ecirun();
}

}

while :
do

	now=$(date + "%T")

	wget -N http://eciresults.nic.in -o $now
	
 	sleep 1m
done
